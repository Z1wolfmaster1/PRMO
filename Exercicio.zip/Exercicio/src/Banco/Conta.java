package Banco;

abstract class Conta {
    String nomeCliente;
    int numero;
    Double saldo;

    public Conta(String nomeCliente, int numero, Double saldo) {
        this.nomeCliente = nomeCliente;
        this.numero = numero;
        this.saldo = saldo;
    }
    
    void saque(Double valor){
        
    }
    
    void deposito(Double valor){
        
    }
    
    void transferencia(Conta c, Double valor){
        
    }
}
