package Banco;

public class Poupanca extends Conta{
    public Poupanca(String nomeCliente, int numero, Double saldo) {
        super(nomeCliente, numero, saldo);
    }
}
