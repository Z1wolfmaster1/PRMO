package Banco;

public class Corrente extends Conta{
    float limite;

    public Corrente(float limite, String nomeCliente, int numero, Double saldo) {
        super(nomeCliente, numero, saldo);
        this.limite = limite;
    }
}